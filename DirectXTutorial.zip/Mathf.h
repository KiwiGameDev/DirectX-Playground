#pragma once

namespace Mathf
{
	static float rad2deg = 57.2957795131f;
	static float deg2rad = 0.0174532925199f;
};
